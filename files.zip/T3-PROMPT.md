Read COMMS.md and CLAUDE.md. You are T3 — Ink Engine + Three.js owner.

ultrathink

Tasks P12 + P13 + P14 + P15 + P16 + P17:

Build the two core differentiators: (1) the Canvas-based ink-sketch image processor with Web Worker offload, and (2) the Three.js parallax depth compositing system using @react-three/fiber. This is the visual engine that makes BIMSEARCH cards look like Arcus Private Wealth materials, not government spreadsheets.

### Requirements

1. **InkSketchProcessor** (src/engine/ink-processor/InkSketchProcessor.ts):
   - Orchestrator class that chains the 8-step pipeline
   - Input: HTMLImageElement or ImageData + ProcessorConfig
   - Output: { result: ImageData, layers: LayerOutput[], intermediates: ImageData[] }
   - Method: `process(image, config)` returns Promise (runs via Worker)
   - Method: `processWithIntermediates(image, config)` returns all 7 intermediate step results (for pipeline visualization in T4's InkProcessor view)

2. **Processing pipeline modules** (each a separate file, pure functions):
   - `grayscale.ts`: ITU-R BT.709 luminance: 0.2126*R + 0.7152*G + 0.0722*B → Float32Array
   - `gaussian-blur.ts`: Separable convolution, configurable σ (default 1.4), kernel_size = ceil(σ*6)|1. Input/output Float32Array
   - `sobel-edges.ts`: 3×3 Gx/Gy Sobel kernels → returns { magnitude: Float32Array, direction: Float32Array }
   - `adaptive-threshold.ts`: Normalize magnitude 0–255, binary threshold at config value → Uint8Array
   - `line-weight.ts`: Scale edge opacity 0.35–1.0 based on edge magnitude → Float32Array
   - `hatching.ts`: Diagonal cross-hatch marks in shadow regions where grayscale < 80. Use direction from Sobel to orient hatches. Returns Float32Array
   - `paper-composite.ts`: Alpha-blend ink (edges + hatching) onto paper color (#FAF8F3 cream or #FFFFFF white) + subtle grain noise (random ±3 per channel). Returns final ImageData

3. **Web Worker** (src/engine/ink-processor/processor.worker.ts):
   - Receives: { imageData: ImageData, config: ProcessorConfig }
   - Runs steps 2–7 (grayscale through hatching) off main thread
   - Posts back: { edges: Float32Array, width, height } or { intermediates: [...] } if requested
   - Step 8 (paper composite) runs on main thread since it writes to visible Canvas
   - Must handle Transferable objects for zero-copy ArrayBuffer transfer

4. **Presets** (src/engine/ink-processor/presets.ts):
   - `ink-heavy`: { threshold: 25, sigma: 1.0, lineWeight: 'heavy', hatching: true } — complex facades, structural steel
   - `ink-light`: { threshold: 55, sigma: 1.8, lineWeight: 'light', hatching: false } — aerial views, wide shots
   - `ink-architectural`: { threshold: 40, sigma: 1.4, lineWeight: 'medium', hatching: true } — terminal interiors, bridges

5. **Layer Splitter** (src/engine/layer-splitter/*):
   - `LayerSplitter.ts`: Takes processed ink-sketch Canvas → splits into 3 depth layers with alpha-feathered masks
   - Default layers: background (startY=0.0, endY=0.45, feather=0.08, factor=0.3, depth=10), midground (0.25–0.75, feather=0.10, factor=0.8, depth=5), foreground (0.60–1.0, feather=0.08, factor=1.5, depth=1)
   - `alpha-feather.ts`: Gradient alpha ramp at layer boundaries — smooth falloff, no hard edges
   - `auto-segment.ts`: Heuristic FG/MG/BG detection based on edge density per vertical third (future enhancement — initial version uses fixed Y splits)
   - Output: Array of { name, dataURL (png), depth, parallaxFactor }

6. **Three.js R3F Components** (src/components/three/*):

   `ParallaxScene.tsx`:
   - R3F Canvas with orthographic camera
   - Props: layers[], intensity (default 0.02), backgroundColor (#FAF8F3), width, height
   - Canvas config: `orthographic`, `gl={{ alpha: true, antialias: true, preserveDrawingBuffer: true }}`
   - Camera: zoom=1, position=[0,0,100], near=0.1, far=1000
   - Mouse tracking via container onMouseMove/onMouseLeave (normalized -1 to 1)
   - Pass mouseRef down to DepthLayer children

   `DepthLayer.tsx`:
   - Single textured plane at specified Z-depth
   - Props: textureUrl, depth, parallaxFactor, mouseRef, intensity
   - Load texture with useTexture (drei), set minFilter/magFilter to LinearFilter
   - useFrame: lerp position toward target (mouseX * factor * viewport.width * intensity) with 0.08 smoothing
   - Material: MeshBasicMaterial, transparent=true, depthWrite=false

   `ParallaxController.tsx`:
   - Manages mouse position state and provides to children
   - Handles scroll-based parallax alternative (parallax-scroll mode)
   - Provides ref for external control (reset, set position)

   `IllustrationViewer.tsx`:
   - Complete integration: takes Opportunity data → checks for illustration_url → if exists, splits into layers → renders ParallaxScene
   - If no illustration: renders procedural scene from SceneGenerator
   - Handles loading states
   - Exposes renderer ref for export (T5 uses this)

7. **Procedural Illustration Generator** (src/engine/procedural/*):
   - `SceneGenerator.ts`: Takes opportunity geography_tag → selects scene type → draws on Canvas using 2D context
   - 5 scene types in scenes/: terminal-curved (MIA), federal-building (USACE/SAM.gov), wide-terminal (DFW), modern-angular (LGA/PANYNJ), curved-tower (MCO)
   - 5 primitives in primitives/: palm-tree, crane, runway, jet-bridge, city-skyline
   - All drawing uses hand-drawn-style line variation: slight random jitter on control points (±2px), varying stroke width (0.5–2px), ink color #1a1a1a at varying opacity (0.3–1.0)
   - Paper grain: subtle noise pattern on background
   - Output: Canvas element ready for layer splitting
   - Each scene selects appropriate primitives (MIA gets palm trees, LGA gets city skyline, etc.)

### Performance targets
- Ink processor: < 3s on desktop (2000px), < 8s on mobile (1200px)
- Parallax: 60fps desktop, 30fps mobile
- Scene init: < 200ms desktop
- Layer texture load: < 100ms each
- GPU memory per card: < 30MB
- Texture cap: 2048×2048 max
- Pixel ratio: Math.min(devicePixelRatio, 2)
- Use invalidateFrameloop — only render when mouse moving
- Dispose textures + geometries on unmount (useEffect cleanup)

### Files you own (ONLY modify these)
- src/engine/ink-processor/InkSketchProcessor.ts
- src/engine/ink-processor/grayscale.ts
- src/engine/ink-processor/gaussian-blur.ts
- src/engine/ink-processor/sobel-edges.ts
- src/engine/ink-processor/adaptive-threshold.ts
- src/engine/ink-processor/line-weight.ts
- src/engine/ink-processor/hatching.ts
- src/engine/ink-processor/paper-composite.ts
- src/engine/ink-processor/processor.worker.ts
- src/engine/ink-processor/presets.ts
- src/engine/layer-splitter/LayerSplitter.ts
- src/engine/layer-splitter/alpha-feather.ts
- src/engine/layer-splitter/auto-segment.ts
- src/engine/procedural/SceneGenerator.ts
- src/engine/procedural/scenes/*.ts (all 5)
- src/engine/procedural/primitives/*.ts (all 5)
- src/components/three/ParallaxScene.tsx
- src/components/three/DepthLayer.tsx
- src/components/three/ParallaxController.tsx
- src/components/three/IllustrationViewer.tsx

### Files you must NOT touch
- src/design/* (T1)
- src/components/layout/* (T1)
- src/components/ui/* (T1)
- src/types/* (T2)
- src/store/* (T2)
- src/api/* (T2)
- src/views/* (T4)
- src/components/cards/* (T4)
- src/components/stats/* (T4)
- tests/* (T5)

### Dependencies
- T1 must have finished: you need package.json with three, @react-three/fiber, @react-three/drei installed
- T2 provides src/types/opportunity.ts (Opportunity interface) — check it exists before importing
- T4 will import ParallaxScene, IllustrationViewer, InkSketchProcessor, LayerSplitter, SceneGenerator
- T5 will access IllustrationViewer's renderer ref for card export

### Constraints
- NEVER run Sobel or Gaussian on main thread — Web Worker is mandatory
- Use Transferable objects in Worker postMessage for zero-copy ArrayBuffer transfer
- Three.js materials: always transparent=true, depthWrite=false
- Always check meshRef.current before accessing in useFrame
- Named exports only
- Use `/compact` if context exceeds 60%

### When done
1. Run `npx tsc --noEmit` — must pass
2. Test ink processor: load a test image → verify output looks like architectural ink sketch
3. Test Three.js: verify 3-layer parallax scene renders at 60fps
4. Update COMMS.md: mark tasks P12–P17 as ✅ DONE
5. Note all exported classes, components, and types in COMMS.md for T4/T5
