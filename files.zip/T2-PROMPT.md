Read COMMS.md and CLAUDE.md. You are T2 — Data Layer + API Server owner.

ultrathink

Tasks P6 + P7 + P8 + P9 + P10 + P11:

Build the complete data layer: TypeScript types matching the Postgres schema, Zustand stores for client state, TanStack Query hooks for all API endpoints, the Fastify REST/WebSocket server, and utility functions. This is the data backbone that T3, T4, and T5 all depend on.

### Requirements

1. **TypeScript interfaces** (src/types/*) — Match the PRD Section 5.1 EXACTLY:
   - `opportunity.ts`: Opportunity, OpportunityStatus (9 values: radar/qualified/jorge_review/contact/proposal/submitted/won/lost/dismissed), Tier (1|2|3), Score (high/medium/low), StatItem
   - `contact.ts`: Contact interface with role_tag, ghl_contact_id
   - `portal.ts`: Portal interface with scan_method, scan_frequency, last_scan_status
   - `card-config.ts`: CardLayout, CardTheme, IllustrationStyle, AnimationStyle, CardConfig
   - `pipeline.ts`: PipelineStage enum/const, stage metadata (id, label, color from CLAUDE.md kanban colors)

2. **Zustand stores** (src/store/*):
   - `useOpportunityStore.ts`: opportunities Map, selectedId, filters (status[], tier[], owner[], portal[]), searchQuery, sortBy, sortOrder
   - `useUIStore.ts`: activeView, selectedOpportunityId, isModalOpen, sidebarCollapsed
   - `useProcessorStore.ts`: currentImage (File|null), processingState ('idle'|'processing'|'done'|'error'), result (ImageData|null), config (threshold, sigma, hatching, preset)

3. **API client** (src/api/client.ts):
   - Fetch wrapper with base URL from env var `VITE_API_URL` (default: http://localhost:3001)
   - JSON headers, error handling, typed responses
   - `apiFetch<T>(path, options)` generic function

4. **TanStack Query hooks** (src/api/*):
   - `opportunities.ts`: useOpportunities(filters), useOpportunity(id), useUpdateOpportunity(), useUploadPhoto()
   - `portals.ts`: usePortals()
   - `kpi.ts`: useKPI(), useDeadlines(days)
   - All with proper query keys, stale times (30s for KPI, 60s for opportunities), background refetch on window focus
   - useUpdateOpportunity must implement optimistic updates for kanban drag-drop

5. **WebSocket client** (src/api/websocket.ts):
   - Connect to `ws://localhost:3001/ws/pipeline`
   - Auto-reconnect with exponential backoff
   - Message types: scan_complete, opportunity_updated, deadline_alert
   - On opportunity_updated → invalidate TanStack Query cache
   - Export a `useWebSocket()` hook

6. **Fastify server** (server/index.ts):
   - Port 3001
   - CORS enabled for localhost:5173
   - Register all route plugins
   - WebSocket support via @fastify/websocket

7. **REST endpoints** (server/routes/*):
   - `GET /api/kpi` → query v_kpi_snapshot view
   - `GET /api/opportunities` → paginated, filterable (status, tier, owner, portal, search via pg_trgm ILIKE, sort, limit/offset)
   - `GET /api/opportunities/:id` → single opp with contacts, documents, actions joined
   - `PATCH /api/opportunities/:id` → update status, owner, pdbm_angle, tags, notes
   - `GET /api/deadlines?days=7` → from v_this_week_deadlines
   - `GET /api/portals` → from v_portal_health
   - `GET /api/alerts?limit=20` → recent alerts
   - `POST /api/opportunities/:id/photos` → file upload (multer/formidable)
   - `PATCH /api/opportunities/:id/photos/:photo_id` → save processed_url

8. **Database** (server/db/*):
   - `pool.ts`: pg Pool using env vars (PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD)
   - `queries.ts`: Named parameterized SQL queries — NO string interpolation, ALL parameterized

9. **WebSocket server** (server/ws/pipeline.ts):
   - Broadcast scan_complete, opportunity_updated, deadline_alert events
   - Connected clients tracked in a Set

10. **Utilities** (src/utils/*):
    - `format.ts`: formatCurrency($137.8M style), formatDate, formatDaysUntil, formatNumber
    - `scoring.ts`: getScoreColor, getTierLabel, getStatusLabel, getStatusColor — using tokens from CLAUDE.md

### Files you own (ONLY modify these)
- src/types/opportunity.ts
- src/types/portal.ts
- src/types/contact.ts
- src/types/card-config.ts
- src/types/pipeline.ts
- src/store/useOpportunityStore.ts
- src/store/useUIStore.ts
- src/store/useProcessorStore.ts
- src/api/client.ts
- src/api/opportunities.ts
- src/api/portals.ts
- src/api/kpi.ts
- src/api/websocket.ts
- src/utils/format.ts
- src/utils/scoring.ts
- server/index.ts
- server/routes/opportunities.ts
- server/routes/portals.ts
- server/routes/kpi.ts
- server/routes/ink-process.ts
- server/db/pool.ts
- server/db/queries.ts
- server/ws/pipeline.ts

### Files you must NOT touch
- src/design/* (T1)
- src/components/layout/* (T1)
- src/components/ui/* (T1)
- src/engine/* (T3)
- src/components/three/* (T3)
- src/views/* (T4)
- src/components/cards/* (T4)
- src/components/stats/* (T4)
- tests/* (T5)

### Dependencies
- T1 must have finished: you need package.json with deps installed and tsconfig.json configured
- T4 will import from src/types/*, src/store/*, src/api/*, src/utils/*
- T3 will import from src/types/opportunity.ts (for Opportunity, CardConfig types)
- T5 will import from src/api/* and src/utils/*

### Constraints
- ALL SQL queries must be parameterized — no string interpolation
- Named exports only (no default exports)
- TanStack Query hooks must return typed data
- Optimistic updates on PATCH /api/opportunities/:id for kanban drag-drop
- Use `/compact` if context exceeds 60%

### When done
1. Run `npx tsc --noEmit` — must pass
2. Update COMMS.md: mark tasks P6–P11 as ✅ DONE
3. Note all exported types, hooks, and store interfaces in COMMS.md for T3/T4/T5
