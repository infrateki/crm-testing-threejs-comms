Read COMMS.md and CLAUDE.md. You are T5 — Export + Polish + Tests owner.

Tasks P26 + P27 + P28 + P29 + P30 + P31 + P32 + P33:

You are the final layer: card export functionality, the CardBuilder view, photo upload flow coordination, animations, responsive design, error handling, and the test suite. Your work makes this production-ready.

### Requirements

1. **CardExporter** (src/components/cards/CardExporter.tsx):
   - Props: opportunity: Opportunity, rendererRef: React.RefObject<THREE.WebGLRenderer>
   - PNG export: capture Three.js scene via renderer.domElement.toDataURL('image/png') at 2x pixel ratio, composite with text overlay (stats bar, headline, metadata) using Canvas 2D text API with correct font metrics from design system
   - SVG export: embed ink-sketch as base64 `<image>` within SVG, add typography as `<text>` elements with correct Playfair Display / DM Sans / JetBrains Mono specs — fully resolution-independent
   - "Copy to Clipboard" using navigator.clipboard.write() with ClipboardItem
   - Buttons: [Export as PNG] [Export as SVG] [Copy to Clipboard]
   - Show progress spinner during export

2. **Export utility** (src/utils/export.ts):
   - `exportAsPNG(renderer, scene, camera, width, height, opportunity)`: Returns data URL string
   - `exportAsSVG(illustrationDataURL, opportunity, config)`: Returns SVG string
   - `downloadFile(dataURL, filename)`: Triggers browser download
   - Text rendering uses Canvas 2D API with font loading check (document.fonts.ready)
   - Export at 2x resolution for print quality (300 DPI equivalent at typical card sizes)

3. **CardBuilder view** (src/views/CardBuilder.tsx):
   - Route: /card-builder
   - Manual card creation form: title, agency, scope, stats (dynamic add/remove), tags, status, tier
   - Illustration selector: upload photo OR choose procedural scene type
   - Live preview: HeroSplitCard renders in real-time as form fields change
   - Export buttons at bottom using CardExporter
   - Useful for creating BD materials without an existing opportunity in the DB

4. **Photo upload flow** (P28 — coordinates across components):
   - In HeroSplitCard (T4 owns the view, you own the upload logic):
     - Create a `usePhotoUpload` hook that: accepts file → uploads via POST /api/opportunities/:id/photos → runs InkSketchProcessor → splits layers → updates Three.js scene → saves processed_url via PATCH
     - Wrap this as a reusable hook that T4's views can call
   - Progress states: uploading → processing → splitting → done
   - Error handling with retry option

5. **Animations** (src/design/animations.css):
   - `@keyframes fadeInUp`: opacity 0→1, translateY 20px→0, 600ms ease-out
   - `@keyframes fadeIn`: opacity 0→1, 400ms ease-out
   - `@keyframes slideInRight`: translateX 20px→0, opacity 0→1, 500ms ease-out
   - `@keyframes countUp`: for CountUp component (handled in JS but CSS transition on the number)
   - `@keyframes shimmer`: loading skeleton animation — gradient slide left-to-right, subtle paper-grain color
   - `@keyframes pulseSubtle`: opacity 0.6→1→0.6, 2s infinite — for deadline urgency
   - Framer Motion page transition config: variants for enter/exit with opacity + translateY
   - Staggered reveal: .stagger-child with transition-delay calc(var(--index) * 100ms)

6. **Responsive design** (P30):
   - Breakpoints: 375px (mobile), 768px (tablet), 1024px (desktop)
   - Mobile (< 768px):
     - Skip Three.js entirely — detect with matchMedia and render static illustration or CSS transform fallback
     - Single-column card grid
     - Kanban: horizontal scroll with snap points instead of 7 visible columns
     - HeroSplitCard: stack vertically (illustration top, content below)
     - Stats bar: 2-column grid instead of horizontal row
     - Nav: hamburger menu
   - Tablet (768–1024px):
     - 2-column card grid
     - Kanban: show 3-4 columns with horizontal scroll for rest
     - HeroSplitCard: 40/60 split
   - Desktop (1024px+): Full layout as designed
   - Detection hook: `useIsMobile()` → returns boolean, uses matchMedia listener

7. **Error boundaries + loading states** (P31):
   - `ErrorBoundary.tsx`: React error boundary wrapper. Renders graceful fallback with paper-grain background, architectural geometric pattern, "Something went wrong" message in DM Sans, and retry button. NOT a blank white screen.
   - `LoadingSkeleton.tsx`: Skeleton loader matching editorial aesthetic. Cream background with subtle shimmer animation. Shape variants: card, text-line, stats-bar, illustration. Uses CSS `@keyframes shimmer` from animations.css.
   - `EmptyState.tsx`: For empty views (no opportunities, no results). Renders procedural geometric line-art pattern (thin lines, architectural feel) with contextual message. Props: title, description, action? button.

8. **Unit tests** (tests/unit/*):
   - `ink-processor.test.ts`: Test grayscale conversion accuracy (known RGB → expected luminance), Sobel edge detection on synthetic test image (white square on black background → edges detected at boundaries), threshold produces binary output
   - `scoring.test.ts`: getScoreColor returns correct hex for each score, getTierLabel returns correct string, getStatusColor matches CLAUDE.md values
   - `layer-splitter.test.ts` (optional): verify alpha mask generation at correct Y positions (optional — add if time)
   - Use Vitest, mock Canvas API where needed

9. **E2E tests** (tests/e2e/*):
   - `showcase.spec.ts`: Navigate to /showcase → verify card grid renders → verify filter changes card count → click card navigates to detail
   - `detail.spec.ts`: Navigate to /opportunities/:id → verify hero-split renders → verify stats bar present → verify tabs switch content
   - `processor.spec.ts`: Navigate to /processor → upload test image → verify processing completes → verify before/after images render
   - Use Playwright

### Files you own (ONLY modify these)
- src/components/cards/CardExporter.tsx
- src/utils/export.ts
- src/views/CardBuilder.tsx
- src/design/animations.css
- src/components/ui/ErrorBoundary.tsx
- src/components/ui/LoadingSkeleton.tsx
- src/components/ui/EmptyState.tsx
- tests/unit/ink-processor.test.ts
- tests/unit/layer-splitter.test.ts
- tests/unit/scoring.test.ts
- tests/e2e/showcase.spec.ts
- tests/e2e/detail.spec.ts
- tests/e2e/processor.spec.ts

### Files you must NOT touch
- src/design/tokens.ts, global.css, fonts.css (T1)
- src/components/layout/* (T1)
- src/components/ui/StatusBadge.tsx, TierBadge.tsx, Tag.tsx, SectionLabel.tsx, SearchInput.tsx, DeadlineCountdown.tsx (T1)
- src/types/* (T2)
- src/store/* (T2)
- src/api/* (T2) — import only
- src/engine/* (T3) — import only
- src/components/three/* (T3) — import only
- src/views/Dashboard.tsx, Showcase.tsx, OpportunityDetail.tsx, Pipeline.tsx, InkProcessor.tsx, PortalHealth.tsx (T4)
- src/components/cards/OpportunityCard.tsx, HeroSplitCard.tsx, CompactKanbanCard.tsx (T4)
- src/components/stats/* (T4)

### Dependencies
- T3 exports: IllustrationViewer (renderer ref access), InkSketchProcessor, LayerSplitter
- T2 exports: API hooks (useUploadPhoto), types (Opportunity, CardConfig)
- T1 exports: design tokens for font metrics in Canvas text rendering, UI components
- T4 exports: HeroSplitCard (used in CardBuilder live preview)

### Constraints
- Export PNG must produce print-quality at 300 DPI equivalent
- SVG must be fully resolution-independent (vector text, not rasterized)
- Error boundaries must maintain editorial aesthetic — no ugly default React error screens
- Loading skeletons use paper-grain shimmer, not generic gray bars
- Mobile detection: matchMedia('(max-width: 767px)') — skip Three.js on true
- Named exports only
- Use `/compact` if context exceeds 60%

### When done
1. Run `npx tsc --noEmit` — must pass
2. Run `npm run test` — unit tests pass
3. Run `npm run build` — must pass
4. Verify: PNG export produces high-quality card image
5. Verify: mobile fallback works (no Three.js errors on small viewport)
6. Update COMMS.md: mark tasks P26–P33 as ✅ DONE
