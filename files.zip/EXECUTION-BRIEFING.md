# BIMSEARCH Command Center — Execution Briefing

## Execution Order

```
Phase 1: T1 (Foundation)         — RUN FIRST, ALONE
         Wait for T1 to finish (5-10 min)

Phase 2: T2 ──────┐
         T3 ──────┤             — RUN IN PARALLEL
         T4 ──────┘             (T4 may need stubs if T2/T3 not done)

Phase 3: T5                      — RUN AFTER T2+T3+T4 finish

Phase 4: Integration Test        — RUN LAST
```

**Note:** T4 depends heavily on T2 (data hooks) and T3 (Three.js components). If T4 starts before T2/T3 finish, it should create minimal type stubs and placeholder components. T5 depends on T3 and T4 outputs.

## Complexity Ratings

| Terminal | Complexity | Est. Time | Model Recommendation |
|---|---|---|---|
| T1 | Medium | 15-25 min | Sonnet (straightforward scaffold) |
| T2 | Heavy | 25-40 min | opusplan (complex types + API design) |
| T3 | Heavy | 30-50 min | opusplan + ultrathink (Sobel math, WebGL, Web Workers) |
| T4 | Heavy | 30-45 min | opusplan (6 views, 3 card types, kanban drag-drop) |
| T5 | Medium | 20-30 min | Sonnet (export, polish, tests) |

## Cross-Terminal Watch List

1. **T2 → T4 dependency:** T4 imports ALL types from src/types/* and ALL hooks from src/api/*. If T2 isn't done, T4 must create placeholder type files.
2. **T3 → T4 dependency:** T4 imports ParallaxScene, IllustrationViewer, InkSketchProcessor from T3. If T3 isn't done, T4 should render static placeholder divs.
3. **T3 → T5 dependency:** T5's CardExporter needs renderer ref from IllustrationViewer. T5 must wait for T3.
4. **T1 → ALL dependency:** T1 installs ALL dependencies. T2/T3/T4 cannot run without T1's package.json.
5. **Shared types contract:** T2 defines the Opportunity interface that T3, T4, and T5 all consume. Any change to this interface must be noted in COMMS.md immediately.

## Recommended Hooks (.claude/settings.json)

```json
{
  "hooks": {
    "PostToolUse": [{
      "matcher": "Write|Edit|MultiEdit",
      "hooks": [{ "type": "command", "command": "npx prettier --write $FILE" }]
    }],
    "Stop": [{
      "hooks": [{ "type": "command", "command": "npx tsc --noEmit" }]
    }]
  },
  "permissions": {
    "allow": [
      "Bash(npm run *)",
      "Bash(npx tsc *)",
      "Bash(npx prettier *)",
      "Bash(npx vite *)",
      "Bash(git *)",
      "Read", "Glob", "Grep"
    ],
    "deny": [
      "Read(./.env)",
      "Read(./.env.*)"
    ]
  }
}
```

## Recommended Subagents

### .claude/agents/code-reviewer.md
```yaml
---
name: code-reviewer
description: Reviews BIMSEARCH code for design system compliance and Three.js best practices
model: haiku
tools: [Read, Glob, Grep, LS]
---
Review changes for: border-radius > 3px violations, Tailwind class usage (forbidden), dark mode colors (forbidden), default exports (forbidden), main-thread Canvas processing (forbidden), Three.js memory leaks (missing dispose). Report violations with file:line references.
```

### .claude/agents/design-auditor.md
```yaml
---
name: design-auditor
description: Audits typography and color token usage against CLAUDE.md design system
model: haiku
tools: [Read, Glob, Grep]
---
Check all CSS and TSX files for: font-family matches (Playfair Display, DM Sans, JetBrains Mono only), color hex values match CLAUDE.md tokens, font-size/weight/letter-spacing match spec per element type. Report any deviations.
```

---

## Integration Test Prompt

Paste this into a terminal AFTER all T1–T5 tasks are marked ✅ DONE in COMMS.md:

```
Read COMMS.md and CLAUDE.md. You are the integration verifier.

1. Run `npm run build` — fix any errors
2. Run `npx tsc --noEmit` — fix any type errors
3. Run `npm run lint` — fix any lint errors
4. Run `npm run test` — fix any test failures
5. Start dev server (`npm run dev`) and verify:
   a. Dashboard loads with KPIBar and layout
   b. Showcase renders card grid with staggered animation
   c. Click card → OpportunityDetail renders hero-split with Three.js parallax
   d. Pipeline kanban shows 7 columns, cards can be dragged between them
   e. InkProcessor accepts file upload and renders ink-sketch result
   f. PortalHealth table renders with color-coded rows
   g. CardBuilder form produces live card preview
6. Verify Three.js parallax: mouse move on illustration produces smooth layered movement
7. Verify mobile: resize to 375px — Three.js skipped, CSS fallback active, no console errors
8. Verify export: click "Export as PNG" on detail view → produces high-res image
9. Check all cross-terminal imports resolve correctly (no missing module errors)
10. Update COMMS.md: mark integration as ✅ DONE or list remaining issues
```
