Read COMMS.md and CLAUDE.md. You are T4 — Views + Cards owner.

ultrathink

Tasks P18 + P19 + P20 + P21 + P22 + P23 + P24 + P25:

Build all 6 application views and all card/stats components. You are the primary consumer of T1's UI primitives, T2's data hooks, and T3's Three.js + ink engine. Every view must match the Arcus/Titan editorial aesthetic — architectural, restrained, premium.

### Requirements

1. **Stats components** (src/components/stats/*):
   - `StatsBar.tsx`: Horizontal bar of stats with 1px dividers. Props: stats: StatItem[], theme: 'light'|'cream'. JetBrains Mono 28–32px/700 for values, DM Sans 11–12px/400/#9CA3AF for labels. Padding 20px vertical. Dividers 1px solid var(--border). Background var(--bg-cream) for cream theme.
   - `StatValue.tsx`: Single stat display (value + label stacked). JetBrains Mono value, DM Sans label.
   - `CountUp.tsx`: Animated number counter. Uses requestAnimationFrame to count from 0 to target over 1.5s with easing. Triggers when element enters viewport (IntersectionObserver). JetBrains Mono font.

2. **Card components** (src/components/cards/*):

   `OpportunityCard.tsx` (compact grid card):
   - Props: opportunity: Opportunity, onClick: () => void
   - Layout: illustration top (use IllustrationViewer from T3 at reduced size), content below
   - Content: SectionLabel (agency), Playfair Display title 24px/900, 2 inline stats, StatusBadge, Tag chips, TierBadge
   - Hover: Three.js parallax activates, subtle scale(1.01) via CSS transition
   - Card: bg white, border 1px solid var(--border), border-radius 3px, shadow 0 1px 3px rgba(0,0,0,0.06)
   - Min-width: 380px for grid

   `HeroSplitCard.tsx` (detail view, full presentation card):
   - Props: opportunity: Opportunity, config?: CardConfig
   - Layout: 50/50 split — left is Three.js IllustrationViewer, right is content
   - Left: IllustrationViewer with mouse-move parallax, full-bleed illustration (no border-radius)
   - Right: SectionLabel (agency), Playfair Display title 36–48px/900, StatusBadge + set-aside badge + geography tag, DM Sans scope text 15px, "PDBM ADVANTAGE" callout block (bordered left with accent-sage), tags + NAICS + solicitation #
   - Below split: Full-width StatsBar with opportunity.stats
   - [Upload Photo] button on illustration area

   `CompactKanbanCard.tsx` (minimal kanban card):
   - Props: opportunity: Opportunity, onClick: () => void, isDragging?: boolean
   - Layout: compact — title (DM Sans 14px/600), agency (12px/400 #6B7280), estimated_value (JetBrains Mono 13px), DeadlineCountdown, TierBadge
   - No illustration (too heavy for 7-column layout)
   - Drag state: slight elevation shadow, opacity 0.8
   - Card: bg white, border 1px solid var(--border), border-radius 3px, padding 12px

3. **Dashboard view** (src/views/Dashboard.tsx):
   - Route: /
   - KPIBar integration: use useKPI() hook → display Active, Pursuing, Submitted, Pipeline Value
   - Hot Opportunity section: useOpportunities({ hot: true, limit: 1 }) → render as HeroSplitCard with full Three.js parallax
   - This Week Deadlines: useDeadlines(7) → list with DeadlineCountdown, click navigates to detail
   - Recent Scans: usePortals({ recent_scans: true }) → portal name + status icon (✓ green, ⚠ yellow, ✗ red) + count
   - Team Workload: from KPI data → horizontal bar per team member
   - Layout follows PRD Section 6.1 wireframe exactly

4. **Showcase view** (src/views/Showcase.tsx):
   - Route: /showcase
   - CSS Grid: repeat(auto-fill, minmax(380px, 1fr)), gap 24px
   - Filter bar: status (multi-select), tier (1/2/3 toggles), owner (dropdown), portal (dropdown), search input (uses pg_trgm via API)
   - Sort: by deadline (default), value, score, last updated
   - Cards use OpportunityCard with staggered entrance animation (opacity 0→1, translateY 20px→0, 100ms delay per card index)
   - Click card → navigate to /opportunities/:id with shared layout animation (Framer Motion)
   - Pagination or infinite scroll

5. **OpportunityDetail view** (src/views/OpportunityDetail.tsx):
   - Route: /opportunities/:id
   - Uses useOpportunity(id) hook
   - Top: Back button (← Back to Showcase)
   - Hero section: Full HeroSplitCard with Three.js parallax
   - Below card: StatsBar with all opportunity.stats
   - Tab section: Contacts | Documents | Actions | Timeline
     - Contacts tab: cards with name, title, org, email, phone, role_tag badge
     - Documents tab: file list with name, type icon, download link
     - Actions tab: chronological action log with timestamps
     - Timeline tab: status change history
   - Bottom: Card Export section (placeholder — T5 owns CardExporter)

6. **Pipeline kanban** (src/views/Pipeline.tsx):
   - Route: /pipeline
   - 7 columns matching stages: Radar, Qualified, Jorge Review, Contact, Proposal, Won, Lost
   - Column headers: stage name + color dot + count badge
   - Column colors from CLAUDE.md kanban stage colors (subtle background at 5% opacity)
   - Cards: CompactKanbanCard inside each column
   - Drag-and-drop: implement with native HTML5 drag API (onDragStart, onDragOver, onDrop)
   - On drop: call useUpdateOpportunity mutation with new status → optimistic update
   - Filter: owner dropdown (All / Jorge / Sergio / Julio / Shami)
   - Columns scroll independently if overflow

7. **InkProcessor view** (src/views/InkProcessor.tsx):
   - Route: /processor
   - File upload area (drag-and-drop + click)
   - Controls panel: preset selector (ink-heavy/light/architectural), threshold slider (0–100), sigma slider (0.5–3.0), hatching toggle, paper selector (cream/white)
   - Before/After split view: original photo left, processed result right
   - Processing pipeline visualization: 7 thumbnails showing each intermediate step (grayscale → blur → edges → threshold → line weight → hatching → composite)
   - Progress indicator during processing
   - Action buttons: Download PNG, Download SVG, Assign to Opportunity (dropdown)
   - Uses InkSketchProcessor.processWithIntermediates() from T3

8. **PortalHealth view** (src/views/PortalHealth.tsx):
   - Route: /portals
   - Table: Portal Name, Type, Tier, Scan Method, Frequency, Last Scan, Status, Opps Found, Notes
   - Row colors: green (success + on schedule), yellow (partial or approaching overdue), red (failed or overdue), gray (inactive)
   - Click row → expand to show recent scan log
   - Uses usePortals() hook from T2

### Files you own (ONLY modify these)
- src/components/stats/StatsBar.tsx
- src/components/stats/StatValue.tsx
- src/components/stats/CountUp.tsx
- src/components/cards/OpportunityCard.tsx
- src/components/cards/HeroSplitCard.tsx
- src/components/cards/CompactKanbanCard.tsx
- src/views/Dashboard.tsx
- src/views/Showcase.tsx
- src/views/OpportunityDetail.tsx
- src/views/Pipeline.tsx
- src/views/InkProcessor.tsx
- src/views/PortalHealth.tsx

### Files you must NOT touch
- src/design/* (T1)
- src/components/layout/* (T1)
- src/components/ui/* (T1) — import only
- src/types/* (T2) — import only
- src/store/* (T2) — import only
- src/api/* (T2) — import only
- src/utils/* (T2) — import only
- src/engine/* (T3) — import only
- src/components/three/* (T3) — import only
- src/components/cards/CardExporter.tsx (T5)
- src/views/CardBuilder.tsx (T5)
- tests/* (T5)

### Dependencies
- T1 exports: StatusBadge, TierBadge, Tag, SectionLabel, SearchInput, DeadlineCountdown, Shell, Header, KPIBar, design tokens
- T2 exports: all types (Opportunity, Portal, Contact, etc.), all hooks (useOpportunities, useKPI, useDeadlines, usePortals, useUpdateOpportunity), all stores, format/scoring utils
- T3 exports: ParallaxScene, IllustrationViewer, InkSketchProcessor, LayerSplitter, SceneGenerator
- CHECK that T1, T2, T3 files exist before importing — if missing, create minimal type stubs as placeholders

### Constraints
- NO Tailwind — vanilla CSS with custom properties
- NO component libraries
- Card border-radius: 3px max
- All typography must match design system spec exactly (font, size, weight, color, spacing)
- Staggered animations: 100ms delay per card index
- Kanban drag-drop must use optimistic updates
- Named exports only
- Use `/compact` if context exceeds 60%

### When done
1. Run `npx tsc --noEmit` — must pass
2. Run `npm run build` — must pass
3. Verify: all 6 views render (with demo data if API not ready)
4. Verify: kanban drag-drop updates state
5. Verify: card typography matches design system
6. Update COMMS.md: mark tasks P18–P25 as ✅ DONE
